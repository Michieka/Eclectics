import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BoardModeratorComponent } from './moderator.component';

describe('ModeratorComponent', () => {
  let component: moderatorComponent;
  let fixture: ComponentFixture<moderatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ moderatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(moderatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});